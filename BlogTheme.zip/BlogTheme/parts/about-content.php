<?php
the_title('<h2>', '</h2>');
the_content();
?>