<?php get_header(); ?>
    <div class='page-not-found'>
        <div class="not-found-content">
            <h1>404</h1>
            <P>Sorry the page you are looking for does not exist :\.</P>
        </div>
    </div>
<?php get_footer(); ?>