<?php if(is_active_sidebar('sidebar-socials')):
        dynamic_sidebar('sidebar-socials');

endif;
?>

