<?php if(is_active_sidebar('sidebar-slfooter')):
        dynamic_sidebar('sidebar-slfooter');

endif;
?>