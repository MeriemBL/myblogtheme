<?php if(is_active_sidebar('sidebar-abfooter')):
        dynamic_sidebar('sidebar-abfooter');

endif;
?>